﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace ApiService.Http
{
    public class Metodo
    {

        public static T GET<T>(string url, string id = "")
        {
            try
            {
                T obj = default(T);
                var client = InstanciarHttpClient();
                var response = client.GetAsync(url + id).Result;
                var result = response.Content.ReadAsStringAsync().Result;
                if (response.IsSuccessStatusCode)
                {
                    obj = JsonConvert.DeserializeObject<T>(result);
                }
                else
                {
                    ApiLog.Log.FazLog(
                        Mensagem: result,
                        Versao: ConfiguracaoDTO.GetInstance.Version);
                }
                return obj;
            }
            catch (Exception ex)
            {
                ApiLog.Log.FazLog(
              Mensagem: "GET BY ID " + ex.StackTrace + (ex.Message ?? "Message NULL ") + (ex.InnerException?.Message ?? "InnerException NULL"),
                    Versao: ConfiguracaoDTO.GetInstance.Version,
                    Exception: ex);

                Console.Write(ex.Message);
            }
            return default(T);
        }

        public static List<T> GETALL<T>(string url)
        {
            List<T> list = null;
            try
            {

                var client = InstanciarHttpClient();
                var response = client.GetAsync(url).Result;
                var result = response.Content.ReadAsStringAsync().Result;
                if (response.IsSuccessStatusCode)
                {
                    list = JsonConvert.DeserializeObject<List<T>>(result);
                }
                else
                {
                    ApiLog.Log.FazLog(
                        Mensagem: result,
                        Versao: ConfiguracaoDTO.GetInstance.Version);
                }
            }
            catch (Exception ex)
            {
                ApiLog.Log.FazLog(
                     Mensagem: "GET ALL " + ex.StackTrace + (ex.Message ?? "Message NULL ") + (ex.InnerException?.Message ?? "InnerException NULL"),
                     Versao: ConfiguracaoDTO.GetInstance.Version,
                     Exception: ex);

                Console.Write(ex.Message);
            }
            return list;
        }

        public static HttpStatusCode DELETE(string url, string id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(id))
                {
                    throw new Exception("Obrigatório informar o id para métodos do tipo DELETE.");
                }
                var client = InstanciarHttpClient();
                var response = client.DeleteAsync(url + id).Result;

                if (!response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;

                    ApiLog.Log.FazLog(
                             Mensagem: (url + id) + " " + result,
                            Versao: ConfiguracaoDTO.GetInstance.Version);
                }

                return response.StatusCode;
            }
            catch (Exception ex)
            {
                ApiLog.Log.FazLog(
                 Mensagem: "DELETE " + ex.StackTrace + (ex.Message ?? "Message NULL ") + (ex.InnerException?.Message ?? "InnerException NULL"),
                Versao: ConfiguracaoDTO.GetInstance.Version,
                Exception: ex);

                throw new InvalidOperationException($"Falha na Operação", ex);
            }
        }

        public static T POST<T>(T _objeto, string _url)
            => PostOrPutObject(_objeto, _url, false);


        public static T PUT<T>(T _objeto, string _url, string id)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                throw new Exception("Obrigatório informar o id para métodos do tipo PUT.");
            }
            return PostOrPutObject(_objeto, _url, true, id);
        }

        private static T PostOrPutObject<T>(T _objeto, string _url, bool _put, string id = "")
        {
            T objeto = default(T);
            var _stringContentErro = "";
            var _resultErro = "";
            try
            {
                var client = InstanciarHttpClient();
                var json = JsonConvert.SerializeObject(_objeto);
                var stringContent = new StringContent(json, Encoding.UTF8, "application/json");
                _stringContentErro = json;

                var response = _put
                   ? client.PutAsync(_url + id, stringContent).Result
                   : client.PostAsync(_url, stringContent).Result;

                var result = response.Content.ReadAsStringAsync().Result;
                _resultErro = result;
                if (response.IsSuccessStatusCode)
                {
                    try
                    {
                        objeto = JsonConvert.DeserializeObject<T>(result);
                    }
                    catch
                    {
                        objeto = _objeto;
                    }
                }
                else
                {
                    ApiLog.Log.FazLog(
                      Mensagem: $"JSON RESPOSTA SERVIDOR :{_resultErro}",
                    Versao: ConfiguracaoDTO.GetInstance.Version);

                    ApiLog.Log.FazLog(
                       Mensagem: $"JSON ENVIADO PARA O SERVIDOR :{json}",
                    Versao: ConfiguracaoDTO.GetInstance.Version);
                }
                return objeto;
            }
            catch (Exception ex)
            {
                //if (ex)
                //{

                //}
                ApiLog.Log.FazLog(Mensagem: "POST OR PUT " + ex.StackTrace + (ex.Message ?? "Message NULL ") + (ex.InnerException?.Message ?? "InnerException NULL"),
                    Versao: ConfiguracaoDTO.GetInstance.Version,
                    Exception: ex);

                return default(T);
            }
        }

        static HttpClient InstanciarHttpClient()
        {
            if (string.IsNullOrWhiteSpace(ConfiguracaoDTO.GetInstance.ConfSync.Host))
            {
                throw new InvalidOperationException($"Host Inválido");
            }

            HttpClient client = null;
            if (ConfiguracaoDTO.GetInstance.ConfSync.TypeAuthentication == Util.TypeAuthentication.None)
            {
                client = ClientHelper.GetClient();
            }
            else if (ConfiguracaoDTO.GetInstance.ConfSync.TypeAuthentication == Util.TypeAuthentication.BasicAuth)
            {
                client = ClientHelper.GetClient(ConfiguracaoDTO.GetInstance.ConfSync.Username, ConfiguracaoDTO.GetInstance.ConfSync.Password);
            }
            else
            {
                client = ClientHelper.GetClient(ConfiguracaoDTO.GetInstance.ConfSync.Token);
            }
            client.Timeout = new TimeSpan(1, 0, 0);
            client.BaseAddress = new Uri(ConfiguracaoDTO.GetInstance.ConfSync.Host);
            
            return client;
        }
    }

    public static class ClientHelper
    {
        // Basic auth
        public static HttpClient GetClient(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username))
            {
                throw new InvalidOperationException($"Username Inválido");
            }
            if (string.IsNullOrWhiteSpace(password))
            {
                throw new InvalidOperationException($"Password Inválido");
            }
            var authValue = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes($"{username}:{password}")));
            var client = new HttpClient()
            {
                DefaultRequestHeaders = { Authorization = authValue }
                //Set some other client defaults like timeout / BaseAddress
            };
            return client;
        }

        // Auth with bearer token
        public static HttpClient GetClient(string token)
        {
            if (string.IsNullOrWhiteSpace(token))
            {
                throw new InvalidOperationException($"Token Inválido");
            }
            var authValue = new AuthenticationHeaderValue("Bearer", token);
            var client = new HttpClient()
            {
                DefaultRequestHeaders = { Authorization = authValue }
                //Set some other client defaults like timeout / BaseAddress
            };
            return client;
        }

        // Auth with bearer token
        public static HttpClient GetClient()
        {
            var client = new HttpClient();
            return client;
        }
    }
}
