﻿namespace ApiService.Util
{
    public interface IConfSync
    {
        string Host { get; set; }
        string Username { get; set; }
        string Password { get; set; }
        string EndPointGetToken { get; set; }
        string GrantType { get; set; }
    }
}
