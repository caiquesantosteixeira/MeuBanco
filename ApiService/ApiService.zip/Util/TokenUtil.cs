﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace ApiService.Util
{
    public class TokenUtil
    {
        public static bool IsTokenValido(string token)
        {
            if (string.IsNullOrWhiteSpace(token))
            {
                return false;
            }
            TokenOption tokenOption = new TokenOption();
            var tokenHandler = new JwtSecurityTokenHandler();
            JwtSecurityToken parsedJwt = tokenHandler.ReadToken(token) as JwtSecurityToken;
            var exp = parsedJwt.Payload.Exp ?? 0;
            var segundos = DateTimeOffset.Now.ToUnixTimeSeconds();
            return exp > segundos;
        }

        public static Token GetToken(IConfSync confSync)
        {
            Token token = null;
            try
            {
                var authValue = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes($"{confSync.Username}:{confSync.Password}")));
                var client = new HttpClient
                {
                    BaseAddress = new Uri(confSync.Host),
                    DefaultRequestHeaders = { Authorization = authValue }
                };
                client.DefaultRequestHeaders.Accept.Clear();

                var login = new Dictionary<string, string>
                {
                    { "grant_type", confSync.GrantType},
                };

                var response = client.PostAsync(confSync.EndPointGetToken, new FormUrlEncodedContent(login))?.Result;

                if (response.IsSuccessStatusCode)
                {
                    token = JsonConvert.DeserializeObject<Token>(response.Content.ReadAsStringAsync().Result);
                }
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    throw new InvalidOperationException($"Usuário e senha invalido para sincronização\n " + result, new Exception());
                }
                else
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    throw new InvalidOperationException(result);
                }
            }
            catch (Exception ex)
            {
                token = null;
            }
            return token;
        }
    }
}
