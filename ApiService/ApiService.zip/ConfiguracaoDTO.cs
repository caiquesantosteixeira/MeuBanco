﻿using ApiService.Util;

namespace ApiService
{
    public class ConfiguracaoDTO
    {
        public ConfSync ConfSync { get; set; }
        public string Version { get; set; }


        private static ConfiguracaoDTO instance;
        public static ConfiguracaoDTO GetInstance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ConfiguracaoDTO();
                }
                return instance;
            }
        }
    }

    public class ConfSync : IConfSync
    {
        public string Host { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Token { get; set; }
        public string EndPointGetToken { get; set; }
        public string GrantType { get; set; }

        public TypeAuthentication TypeAuthentication { get; set; }
    }
}
